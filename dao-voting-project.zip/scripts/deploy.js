import hre from "hardhat";
import fs from "fs";
import path from "path";

async function main() {
  console.log("Deploying MemberDAO...");

  const MemberDAO = await hre.ethers.getContractFactory("MemberDAO");
  const memberDAO = await MemberDAO.deploy();

  await memberDAO.waitForDeployment();

  const contractAddress = await memberDAO.getAddress();

  console.log("MemberDAO deployed to:", contractAddress);

  const artifact = await hre.artifacts.readArtifact("MemberDAO");

  const configContent = `
const CONTRACT_ADDRESS = "${contractAddress}";

const CONTRACT_ABI = ${JSON.stringify(artifact.abi, null, 2)};
`;

  const configPath = path.join(process.cwd(), "frontend/config.js");

  fs.writeFileSync(configPath, configContent);

  console.log("Frontend config.js updated successfully.");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
