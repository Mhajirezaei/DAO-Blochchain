# Member DAO Voting

A simple decentralized DAO voting system built with Solidity, Hardhat, HTML, CSS, and JavaScript.

## Features

- DAO member management
- Create proposals
- Vote YES/NO
- One address, one vote per proposal
- Time-limited voting
- Execute proposals after deadline
- MetaMask connection
- Simple frontend with HTML/CSS/JS

## Tech Stack

- Solidity
- Hardhat
- ethers.js
- HTML
- CSS
- JavaScript

## Install
```bash
npm install
