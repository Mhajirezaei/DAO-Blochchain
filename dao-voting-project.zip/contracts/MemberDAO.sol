// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract MemberDAO {
    address public owner;
    uint256 public proposalCount;
    uint256 public memberCount;

    struct Proposal {
        uint256 id;
        string title;
        string description;
        uint256 yesVotes;
        uint256 noVotes;
        uint256 deadline;
        bool executed;
        bool exists;
    }

    mapping(address => bool) public members;
    mapping(uint256 => Proposal) public proposals;
    mapping(uint256 => mapping(address => bool)) public hasVoted;

    event MemberAdded(address indexed member);
    event MemberRemoved(address indexed member);

    event ProposalCreated(
        uint256 indexed proposalId,
        string title,
        string description,
        uint256 deadline
    );

    event Voted(
        uint256 indexed proposalId,
        address indexed voter,
        bool support
    );

    event ProposalExecuted(
        uint256 indexed proposalId,
        bool passed
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner allowed");
        _;
    }

    modifier onlyMember() {
        require(members[msg.sender], "Only DAO members allowed");
        _;
    }

    modifier proposalExists(uint256 proposalId) {
        require(proposals[proposalId].exists, "Proposal does not exist");
        _;
    }

    constructor() {
        owner = msg.sender;
        members[msg.sender] = true;
        memberCount = 1;

        emit MemberAdded(msg.sender);
    }

    function addMember(address member) public onlyOwner {
        require(member != address(0), "Invalid address");
        require(!members[member], "Already a member");

        members[member] = true;
        memberCount++;

        emit MemberAdded(member);
    }

    function removeMember(address member) public onlyOwner {
        require(member != address(0), "Invalid address");
        require(members[member], "Not a member");
        require(member != owner, "Owner cannot be removed");

        members[member] = false;
        memberCount--;

        emit MemberRemoved(member);
    }

    function createProposal(
        string memory title,
        string memory description,
        uint256 durationInMinutes
    ) public onlyMember {
        require(bytes(title).length > 0, "Title is required");
        require(bytes(description).length > 0, "Description is required");
        require(durationInMinutes > 0, "Duration must be greater than zero");

        proposalCount++;

        uint256 deadline = block.timestamp + durationInMinutes * 1 minutes;

        proposals[proposalCount] = Proposal({
            id: proposalCount,
            title: title,
            description: description,
            yesVotes: 0,
            noVotes: 0,
            deadline: deadline,
            executed: false,
            exists: true
        });

        emit ProposalCreated(
            proposalCount,
            title,
            description,
            deadline
        );
    }

    function vote(uint256 proposalId, bool support)
        public
        onlyMember
        proposalExists(proposalId)
    {
        Proposal storage proposal = proposals[proposalId];

        require(block.timestamp < proposal.deadline, "Voting has ended");
        require(!hasVoted[proposalId][msg.sender], "Already voted");

        hasVoted[proposalId][msg.sender] = true;

        if (support) {
            proposal.yesVotes++;
        } else {
            proposal.noVotes++;
        }

        emit Voted(proposalId, msg.sender, support);
    }

    function executeProposal(uint256 proposalId)
        public
        proposalExists(proposalId)
    {
        Proposal storage proposal = proposals[proposalId];

        require(block.timestamp >= proposal.deadline, "Voting is still active");
        require(!proposal.executed, "Already executed");

        proposal.executed = true;

        bool passed = proposal.yesVotes > proposal.noVotes;

        emit ProposalExecuted(proposalId, passed);
    }

    function getProposal(uint256 proposalId)
        public
        view
        proposalExists(proposalId)
        returns (
            uint256 id,
            string memory title,
            string memory description,
            uint256 yesVotes,
            uint256 noVotes,
            uint256 deadline,
            bool executed,
            bool active,
            bool passed
        )
    {
        Proposal memory proposal = proposals[proposalId];

        bool isActive = block.timestamp < proposal.deadline;
        bool isPassed = proposal.yesVotes > proposal.noVotes;

        return (
            proposal.id,
            proposal.title,
            proposal.description,
            proposal.yesVotes,
            proposal.noVotes,
            proposal.deadline,
            proposal.executed,
            isActive,
            isPassed
        );
    }
}
