let provider;
let signer;
let contract;
let currentAccount;

const connectWalletBtn = document.getElementById("connectWalletBtn");

const walletAddressEl = document.getElementById("walletAddress");
const contractAddressEl = document.getElementById("contractAddress");
const ownerAddressEl = document.getElementById("ownerAddress");
const memberCountEl = document.getElementById("memberCount");
const proposalCountEl = document.getElementById("proposalCount");
const membershipStatusEl = document.getElementById("membershipStatus");

const memberAddressInput = document.getElementById("memberAddressInput");
const addMemberBtn = document.getElementById("addMemberBtn");

const removeMemberAddressInput = document.getElementById("removeMemberAddressInput");
const removeMemberBtn = document.getElementById("removeMemberBtn");

const proposalTitleInput = document.getElementById("proposalTitleInput");
const proposalDescriptionInput = document.getElementById("proposalDescriptionInput");
const proposalDurationInput = document.getElementById("proposalDurationInput");
const createProposalBtn = document.getElementById("createProposalBtn");

const voteProposalIdInput = document.getElementById("voteProposalIdInput");
const voteYesBtn = document.getElementById("voteYesBtn");
const voteNoBtn = document.getElementById("voteNoBtn");

const executeProposalIdInput = document.getElementById("executeProposalIdInput");
const executeProposalBtn = document.getElementById("executeProposalBtn");

const getProposalIdInput = document.getElementById("getProposalIdInput");
const getProposalBtn = document.getElementById("getProposalBtn");
const proposalResult = document.getElementById("proposalResult");

const loadAllProposalsBtn = document.getElementById("loadAllProposalsBtn");
const allProposals = document.getElementById("allProposals");

const toast = document.getElementById("toast");

window.addEventListener("load", () => {
  contractAddressEl.innerText = CONTRACT_ADDRESS || "Not deployed yet";

  if (!CONTRACT_ADDRESS || CONTRACT_ABI.length === 0) {
    showToast("Contract address or ABI is empty. Deploy contract first.");
  }
});

function showToast(message) {
  toast.innerText = message;
  toast.classList.add("show");

  setTimeout(() => {
    toast.classList.remove("show");
  }, 4500);
}

function shortAddress(address) {
  if (!address) return "---";
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function formatDate(timestamp) {
  const date = new Date(Number(timestamp) * 1000);
  return date.toLocaleString();
}

function checkContractConfig() {
  if (!CONTRACT_ADDRESS || CONTRACT_ABI.length === 0) {
    throw new Error("Contract is not configured. Please deploy first.");
  }
}

async function connectWallet() {
  try {
    checkContractConfig();

    if (!window.ethereum) {
      alert("MetaMask is not installed!");
      return;
    }

    provider = new ethers.BrowserProvider(window.ethereum);

    await provider.send("eth_requestAccounts", []);

    signer = await provider.getSigner();
    currentAccount = await signer.getAddress();

    contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

    walletAddressEl.innerText = currentAccount;
    connectWalletBtn.innerText = `Connected: ${shortAddress(currentAccount)}`;

    showToast("Wallet connected successfully.");

    await loadDAOInfo();
  } catch (error) {
    console.error(error);
    showToast(error.message || "Wallet connection failed.");
  }
}

async function loadDAOInfo() {
  try {
    if (!contract || !currentAccount) return;

    const owner = await contract.owner();
    const memberCount = await contract.memberCount();
    const proposalCount = await contract.proposalCount();
    const isMember = await contract.members(currentAccount);

    ownerAddressEl.innerText = owner;
    memberCountEl.innerText = memberCount.toString();
    proposalCountEl.innerText = proposalCount.toString();
    membershipStatusEl.innerText = isMember ? "Member" : "Not Member";
  } catch (error) {
    console.error(error);
    showToast("Failed to load DAO info.");
  }
}

async function addMember() {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    const memberAddress = memberAddressInput.value.trim();

    if (!ethers.isAddress(memberAddress)) {
      showToast("Invalid member address.");
      return;
    }

    const tx = await contract.addMember(memberAddress);

    showToast("Transaction sent. Waiting...");
    await tx.wait();

    showToast("Member added successfully.");
    memberAddressInput.value = "";

    await loadDAOInfo();
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Add member failed.");
  }
}

async function removeMember() {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    const memberAddress = removeMemberAddressInput.value.trim();

    if (!ethers.isAddress(memberAddress)) {
      showToast("Invalid member address.");
      return;
    }

    const tx = await contract.removeMember(memberAddress);

    showToast("Transaction sent. Waiting...");
    await tx.wait();

    showToast("Member removed successfully.");
    removeMemberAddressInput.value = "";

    await loadDAOInfo();
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Remove member failed.");
  }
}

async function createProposal() {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    const title = proposalTitleInput.value.trim();
    const description = proposalDescriptionInput.value.trim();
    const duration = proposalDurationInput.value.trim();

    if (!title || !description || !duration) {
      showToast("Please fill all proposal fields.");
      return;
    }

    if (Number(duration) <= 0) {
      showToast("Duration must be greater than zero.");
      return;
    }

    const tx = await contract.createProposal(title, description, duration);

    showToast("Transaction sent. Waiting...");
    await tx.wait();

    showToast("Proposal created successfully.");

    proposalTitleInput.value = "";
    proposalDescriptionInput.value = "";
    proposalDurationInput.value = "";

    await loadDAOInfo();
    await loadAllProposals();
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Create proposal failed.");
  }
}

async function vote(proposalId, support) {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    if (!proposalId || Number(proposalId) <= 0) {
      showToast("Invalid proposal ID.");
      return;
    }

    const tx = await contract.vote(proposalId, support);

    showToast("Vote transaction sent. Waiting...");
    await tx.wait();

    showToast(support ? "YES vote submitted." : "NO vote submitted.");

    await getProposalById(proposalId);
    await loadAllProposals();
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Vote failed.");
  }
}

async function executeProposal() {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    const proposalId = executeProposalIdInput.value.trim();

    if (!proposalId || Number(proposalId) <= 0) {
      showToast("Invalid proposal ID.");
      return;
    }

    const tx = await contract.executeProposal(proposalId);

    showToast("Execute transaction sent. Waiting...");
    await tx.wait();

    showToast("Proposal executed successfully.");

    await getProposalById(proposalId);
    await loadAllProposals();
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Execute failed.");
  }
}

async function getProposalById(proposalId) {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    const proposal = await contract.getProposal(proposalId);

    const id = proposal[0].toString();
    const title = proposal[1];
    const description = proposal[2];
    const yesVotes = proposal[3].toString();
    const noVotes = proposal[4].toString();
    const deadline = proposal[5].toString();
    const executed = proposal[6];
    const active = proposal[7];
    const passed = proposal[8];

    proposalResult.innerHTML = `
      <p><strong>ID:</strong> ${id}</p>
      <p><strong>Title:</strong> ${title}</p>
      <p><strong>Description:</strong> ${description}</p>
      <p><strong>YES Votes:</strong> ${yesVotes}</p>
      <p><strong>NO Votes:</strong> ${noVotes}</p>
      <p><strong>Deadline:</strong> ${formatDate(deadline)}</p>
      <p><strong>Executed:</strong> ${executed ? "Yes" : "No"}</p>
      <p><strong>Status:</strong> 
        <span class="${active ? "status-active" : "status-ended"}">
          ${active ? "Active" : "Ended"}
        </span>
      </p>
      <p><strong>Result:</strong> 
        <span class="${passed ? "status-passed" : "status-failed"}">
          ${passed ? "Passed" : "Failed or Not Passed Yet"}
        </span>
      </p>
    `;
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Get proposal failed.");
  }
}

async function loadAllProposals() {
  try {
    if (!contract) {
      showToast("Connect wallet first.");
      return;
    }

    const count = await contract.proposalCount();

    if (Number(count) === 0) {
      allProposals.innerHTML = "No proposals yet.";
      return;
    }

    allProposals.innerHTML = "";

    for (let i = 1; i <= Number(count); i++) {
      const proposal = await contract.getProposal(i);

      const id = proposal[0].toString();
      const title = proposal[1];
      const description = proposal[2];
      const yesVotes = proposal[3].toString();
      const noVotes = proposal[4].toString();
      const deadline = proposal[5].toString();
      const executed = proposal[6];
      const active = proposal[7];
      const passed = proposal[8];

      const div = document.createElement("div");
      div.className = "proposal-item";

      div.innerHTML = `
        <h3>#${id} - ${title}</h3>
        <p><strong>Description:</strong> ${description}</p>
        <p><strong>YES:</strong> ${yesVotes} | <strong>NO:</strong> ${noVotes}</p>
        <p><strong>Deadline:</strong> ${formatDate(deadline)}</p>
        <p><strong>Executed:</strong> ${executed ? "Yes" : "No"}</p>
        <p><strong>Status:</strong> 
          <span class="${active ? "status-active" : "status-ended"}">
            ${active ? "Active" : "Ended"}
          </span>
        </p>
        <p><strong>Result:</strong> 
          <span class="${passed ? "status-passed" : "status-failed"}">
            ${passed ? "Passed" : "Failed or Not Passed Yet"}
          </span>
        </p>
      `;

      allProposals.appendChild(div);
    }

    await loadDAOInfo();
  } catch (error) {
    console.error(error);
    showToast(error.reason || error.shortMessage || "Load proposals failed.");
  }
}

connectWalletBtn.addEventListener("click", connectWallet);

addMemberBtn.addEventListener("click", addMember);
removeMemberBtn.addEventListener("click", removeMember);

createProposalBtn.addEventListener("click", createProposal);

voteYesBtn.addEventListener("click", () => {
  vote(voteProposalIdInput.value.trim(), true);
});

voteNoBtn.addEventListener("click", () => {
  vote(voteProposalIdInput.value.trim(), false);
});

executeProposalBtn.addEventListener("click", executeProposal);

getProposalBtn.addEventListener("click", () => {
  const proposalId = getProposalIdInput.value.trim();
  getProposalById(proposalId);
});

loadAllProposalsBtn.addEventListener("click", loadAllProposals);

if (window.ethereum) {
  window.ethereum.on("accountsChanged", () => {
    window.location.reload();
  });

  window.ethereum.on("chainChanged", () => {
    window.location.reload();
  });
}
